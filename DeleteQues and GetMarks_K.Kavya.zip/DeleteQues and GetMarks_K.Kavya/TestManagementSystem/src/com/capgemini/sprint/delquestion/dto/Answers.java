package com.capgemini.sprint.delquestion.dto;

public class Answers
{
   private int q_id;
   private int ans_opt;
   public Answers() {}
public Answers(int q_id, int ans_opt) {
	super();
	this.q_id = q_id;
	this.ans_opt = ans_opt;
}
public int getQ_id() {
	return q_id;
}
public void setQ_id(int q_id) {
	this.q_id = q_id;
}
public int getAns_opt() {
	return ans_opt;
}
public void setAns_opt(int ans_opt) {
	this.ans_opt = ans_opt;
}
   
}
