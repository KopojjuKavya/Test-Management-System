package com.capgemini.sprint.delquestion.service;

public interface QuestionsSevice 
{
	public int deleteQuestions(int q_id);
}
