package com.capgemini.sprint.delquestion.dao;

import java.util.ArrayList;

public interface GetMarksDao {
	public  ArrayList<Integer> methodanswer();
	public  ArrayList<Integer> methodmarks();
	public ArrayList<Integer> methodchoose();
}
