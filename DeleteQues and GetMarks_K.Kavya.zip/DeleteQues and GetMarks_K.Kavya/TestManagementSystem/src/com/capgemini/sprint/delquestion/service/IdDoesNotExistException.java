package com.capgemini.sprint.delquestion.service;

@SuppressWarnings("serial")
public class IdDoesNotExistException extends Exception {
      public IdDoesNotExistException()
     {
    	 super("Id does not exist");
     }
}
