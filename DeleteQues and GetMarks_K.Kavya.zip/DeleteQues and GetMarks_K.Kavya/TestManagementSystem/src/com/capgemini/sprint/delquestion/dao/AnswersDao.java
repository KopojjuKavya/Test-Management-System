package com.capgemini.sprint.delquestion.dao;

public interface AnswersDao {
	public void openConnection();
	public void close();
	public int deleteAnswers(int q_id);
}
