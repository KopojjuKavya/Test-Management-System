package com.capgemini.sprint.delquestion.dao;

public interface QuestionsDao {
	public void openConnection();
	public void close();
	public int deleteQuestions(int q_id);
}
