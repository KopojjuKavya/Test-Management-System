package com.capgemini.sprint.delquestion.service;

import com.capgemini.sprint.delquestion.dao.QuestionsDao;
import com.capgemini.sprint.delquestion.dao.QuestionsDaoImpl;

public class QuestionsServiceImpl implements QuestionsSevice{
     QuestionsDao dao = new QuestionsDaoImpl();
	@Override
	public int deleteQuestions(int q_id) {
		int rows = dao.deleteQuestions(q_id);
		return rows;
	}

}
