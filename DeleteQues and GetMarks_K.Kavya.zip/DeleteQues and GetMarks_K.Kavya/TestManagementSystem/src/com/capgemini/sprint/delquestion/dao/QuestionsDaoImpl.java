package com.capgemini.sprint.delquestion.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.sprint.delquestion.utlis.QuestionsDBQueries;

public class QuestionsDaoImpl implements QuestionsDao {
    private Connection connection = null;
    private PreparedStatement pst;
	@Override
	public void openConnection() 
	{
	 try 
	 {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		connection = DriverManager.getConnection(url,"kavya","kavya");
	 } 
	 catch (ClassNotFoundException | SQLException e) 
	 {
		e.printStackTrace();
	 }
   }
	@Override
	public void close() 
	{
	 try
	 {
		 connection.close();
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
	 }
	}

	@Override
	public int deleteQuestions(int q_id) 
	{
	int rows = 0;
	openConnection();
	try
	{
		pst = connection.prepareStatement(QuestionsDBQueries.deleteQuestionsQuery);
		pst.setInt(1,q_id);
		rows = pst.executeUpdate();
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	   close();
		return rows;
	}

}
