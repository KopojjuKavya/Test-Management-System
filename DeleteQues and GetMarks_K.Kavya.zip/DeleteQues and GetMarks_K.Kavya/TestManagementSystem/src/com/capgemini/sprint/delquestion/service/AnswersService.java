package com.capgemini.sprint.delquestion.service;

public interface AnswersService
{
	public int deleteAnswers(int q_id);
}
