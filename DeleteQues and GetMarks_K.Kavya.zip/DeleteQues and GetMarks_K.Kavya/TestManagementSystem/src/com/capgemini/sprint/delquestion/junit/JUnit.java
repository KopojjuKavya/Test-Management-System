package com.capgemini.sprint.delquestion.junit;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import com.capgemini.sprint.delquestion.dao.AnswersDao;
import com.capgemini.sprint.delquestion.dao.AnswersDaoImpl;
import com.capgemini.sprint.delquestion.dao.QuestionsDao;
import com.capgemini.sprint.delquestion.dao.QuestionsDaoImpl;

class JUnit {
	QuestionsDao qdao =null;
	AnswersDao adao =null;
	@Before
	public void setUp()
	{
		qdao = new QuestionsDaoImpl();
		adao = new AnswersDaoImpl();
	}
	@After
	public void tearDown()
	{
	      qdao=null;
	      adao=null;
	}
	@Test
	void testDeleteQues()   
	{
		QuestionsDao qdao = new QuestionsDaoImpl();
		AnswersDao adao = new AnswersDaoImpl();
		int rows = qdao.deleteQuestions(5);
		rows = adao.deleteAnswers(5);
		assertEquals(rows, 1);
		assertEquals(rows, 1);
	}
	
	@Test
	void testNegativeDeleteQues()
	{
		QuestionsDao qdao = new QuestionsDaoImpl();
		int rows = qdao.deleteQuestions(4);
		assertNotEquals(rows, 3);
	}
	@Test
	void testNegativeDeleteAns()
	{
		AnswersDao adao = new AnswersDaoImpl();
		int rows = adao.deleteAnswers(4);
		assertNotEquals(rows, 4);
	}
}
