package com.capgemini.sprint.delquestion.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;


public class GetMarksDaoImpl implements GetMarksDao
{
	Connection c=null;
	 Statement st=null;
	
	
	public ArrayList<Integer> q_id=new ArrayList<Integer>();
	public ArrayList<String> q_content=new ArrayList<String>();
	public ArrayList<String> q_option1=new ArrayList<String>();
	public ArrayList<String> q_option2=new ArrayList<String>();
	public ArrayList<String> q_option3=new ArrayList<String>();
	public ArrayList<Integer> q_weightage=new ArrayList<Integer>();
	public ArrayList<Integer> q_answer=new ArrayList<Integer>();
	public ArrayList<Integer> choosen_answer=new ArrayList<Integer>();
	
	
	@Override
	public  ArrayList<Integer> methodanswer()
	{
		
		try
		{
	 Connection con=GetMarksDB.getconnection1();
	 st=con.createStatement();
	 ResultSet rs=st.executeQuery("select * from questions");
	 while(rs.next())
	 {
		 q_id.add(rs.getInt(1));
		 q_content.add(rs.getString(2));
		 q_option1.add(rs.getString(3));
		 q_option2.add(rs.getString(4));
		 q_option3.add(rs.getString(5));
		 q_weightage.add(rs.getInt(6));		 
	 }
	
	 ResultSet rs1=st.executeQuery("select * from answers");
	 while(rs1.next())
	 {
		 q_answer.add(rs1.getInt(2));
	 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return q_answer;	
	}
	@Override
	public  ArrayList<Integer> methodmarks()
	{
		return q_weightage;
		
	}
	public ArrayList<Integer> methodchoose()
	{
		int count=q_id.size();
		for(int i=0;i<count;i++)
		{
	       System.out.println(q_id.get(i)+")"+q_content.get(i));
	       System.out.println("Options:");
	       System.out.println("1."+q_option1.get(i)+"\n"+"2."+q_option2.get(i)+"\n"+"3."+q_option3.get(i));
	       @SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
	       int a=sc.nextInt();
	       choosen_answer.add(a);       	
	}
		return choosen_answer;
	}
	

}
