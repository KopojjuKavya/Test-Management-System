package com.capgemini.sprint.delquestion.utlis;

public class QuestionsDBQueries {
	public static String deleteQuestionsQuery = "delete from Questions where q_id = ? ";
	public static String deleteAnswersQuery = "delete from Answers where q_id = ?";
}
