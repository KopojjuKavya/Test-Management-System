package com.capgemini.sprint.delquestion.dto.applications;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.sprint.delquestion.dao.GetMarksDao;
import com.capgemini.sprint.delquestion.dao.GetMarksDaoImpl;
import com.capgemini.sprint.delquestion.service.AnswersService;
import com.capgemini.sprint.delquestion.service.AnswersServiceImpl;
import com.capgemini.sprint.delquestion.service.IdDoesNotExistException;
import com.capgemini.sprint.delquestion.service.QuestionsServiceImpl;
import com.capgemini.sprint.delquestion.service.QuestionsSevice;

public class DeleteQuestionsmain {
	private static Scanner sc;

	public static void main(String args[]) throws ClassNotFoundException, SQLException, IdDoesNotExistException
	{
		QuestionsSevice service = new QuestionsServiceImpl();
		AnswersService ser = new AnswersServiceImpl();
		sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("1.Admin");
			System.out.println("2.User");
			System.out.println("Enter your role ");
			int opt = sc.nextInt();
			switch(opt)
			{
			case 1:sc = new Scanner(System.in);
			System.out.println("Enter the q_id to be deleted : ");
			int n =sc.nextInt();
				if(n>10) 
			   {
				try
				{
				throw new IdDoesNotExistException();
				}
				catch(IdDoesNotExistException i)
				{
					System.out.println(i.getMessage());
				}
			  }
			else
			{
			int rows = service.deleteQuestions(n);
		    rows = ser.deleteAnswers(n);
			if(rows>0)
			{
				System.out.println("Id detected");
				System.out.println("Deleted");
			}
			else
				System.out.println("Id already deleted by admin");
			}
			break;
			case 2:
				GetMarksDao dao=new GetMarksDaoImpl();
			      ArrayList<Integer> choose=new ArrayList<Integer>();
			      ArrayList<Integer> ans=new ArrayList<Integer>();
			      ArrayList<Integer> marks=new ArrayList<Integer>();
			      ans.addAll(dao.methodanswer());
			      choose.addAll(dao.methodchoose());
			      marks.addAll(dao.methodmarks());
			      int c=ans.size();
			      int total=0;
			      for(int i=0;i<c;i++)
			      {
			    	  if(ans.get(i)==choose.get(i))
			    	  {
			    		  total=total+marks.get(i);
			    	  }
			      }
			      System.out.println("The marks you have obtained are: "+total);
			}
		}
	}

}
