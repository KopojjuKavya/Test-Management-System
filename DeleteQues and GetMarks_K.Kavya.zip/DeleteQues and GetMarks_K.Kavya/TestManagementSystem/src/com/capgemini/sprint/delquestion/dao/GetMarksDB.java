package com.capgemini.sprint.delquestion.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GetMarksDB {


public static Connection getconnection1() throws ClassNotFoundException, SQLException {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","kavya","kavya");
	return con;
	
}
}