package com.capgemini.sprint.delquestion.dto;

public class Questions {
           private int q_id;
           private char q_content;
           private char q_option1;
           private char q_option2;
           private char q_option3;
           private char q_marks;
           public Questions() {}
		public Questions(int q_id, char q_content, char q_option1, char q_option2, char q_option3, char q_marks) {
			super();
			this.q_id = q_id;
			this.q_content = q_content;
			this.q_option1 = q_option1;
			this.q_option2 = q_option2;
			this.q_option3 = q_option3;
			this.q_marks = q_marks;
		}
		public int getQ_id() {
			return q_id;
		}
		public void setQ_id(int q_id) {
			this.q_id = q_id;
		}
		public char getQ_content() {
			return q_content;
		}
		public void setQ_content(char q_content) {
			this.q_content = q_content;
		}
		public char getQ_option1() {
			return q_option1;
		}
		public void setQ_option1(char q_option1) {
			this.q_option1 = q_option1;
		}
		public char getQ_option2() {
			return q_option2;
		}
		public void setQ_option2(char q_option2) {
			this.q_option2 = q_option2;
		}
		public char getQ_option3() {
			return q_option3;
		}
		public void setQ_option3(char q_option3) {
			this.q_option3 = q_option3;
		}
		public char getQ_marks() {
			return q_marks;
		}
		public void setQ_marks(char q_marks) {
			this.q_marks = q_marks;
		}
           
}
