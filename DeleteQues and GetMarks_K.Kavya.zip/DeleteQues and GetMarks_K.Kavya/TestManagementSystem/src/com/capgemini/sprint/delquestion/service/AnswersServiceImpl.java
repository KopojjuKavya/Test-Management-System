package com.capgemini.sprint.delquestion.service;

import com.capgemini.sprint.delquestion.dao.AnswersDao;
import com.capgemini.sprint.delquestion.dao.AnswersDaoImpl;

public class AnswersServiceImpl implements AnswersService {
	AnswersDao dao = new AnswersDaoImpl();
	@Override
	public int deleteAnswers(int q_id) {
		int rows = dao.deleteAnswers(q_id);
		return rows;
	}

}
